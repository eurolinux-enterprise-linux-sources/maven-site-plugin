package org.apache.maven.titi;
/**
 * Hello world!
 *
 */
public class AppFoo 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
