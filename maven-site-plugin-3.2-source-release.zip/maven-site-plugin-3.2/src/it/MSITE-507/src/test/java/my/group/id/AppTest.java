package my.group.id;

import org.junit.*;

import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import static org.junit.matchers.JUnitMatchers.*;

/**
 * Unit test for simple App.
 */
public class AppTest  {

  @Test
  public void testApp() {
    assertTrue( true );
  }
}
