package test;

public class Test {
	public void test(){
	}
}
